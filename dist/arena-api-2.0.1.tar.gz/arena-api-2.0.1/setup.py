# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['arena_api',
 'arena_api.__future__',
 'arena_api._xlayer',
 'arena_api._xlayer.binary',
 'arena_api._xlayer.xarena',
 'arena_api._xlayer.xsave']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'arena-api',
    'version': '2.0.1',
    'description': '',
    'long_description': None,
    'author': 'Zac Pullen',
    'author_email': 'zac@greenroomrobotics.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
